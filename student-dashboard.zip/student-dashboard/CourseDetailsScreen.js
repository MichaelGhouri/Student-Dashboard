import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useThemeContext } from './ThemeProvider';

export default function CourseDetailsScreen({ route }) {
  const { currentTheme } = useThemeContext();
  const { course } = route.params;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.colors.background }]}>
      <View style={[styles.card, { backgroundColor: currentTheme.colors.card }]}>
        <Text style={[styles.title, { color: currentTheme.colors.text }]}>Course Details</Text>
        <Text style={[styles.label, { color: currentTheme.colors.text }]}>Course Name:</Text>
        <Text style={[styles.value, { color: currentTheme.colors.textSecondary }]}>{course.name}</Text>
        <Text style={[styles.label, { color: currentTheme.colors.text }]}>Course Code:</Text>
        <Text style={[styles.value, { color: currentTheme.colors.textSecondary }]}>{course.code}</Text>
        <Text style={[styles.label, { color: currentTheme.colors.text }]}>Instructor:</Text>
        <Text style={[styles.value, { color: currentTheme.colors.textSecondary }]}>{course.instructor}</Text>
        <Text style={[styles.label, { color: currentTheme.colors.text }]}>Class Timings:</Text>
        <Text style={[styles.value, { color: currentTheme.colors.textSecondary }]}>{course.timings}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  card: { padding: 16, borderRadius: 8, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  label: { fontSize: 16, fontWeight: 'bold', marginTop: 8 },
  value: { fontSize: 14, marginTop: 4 },
});
