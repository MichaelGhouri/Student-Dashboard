import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useThemeContext } from './ThemeProvider';

const students = [
  { id: 1, name: 'Michael Ghouri', studentId: '56116' },
  { id: 2, name: 'Naveed Rajput', studentId: '52877' },
];

export default function StudentSelectionScreen({ navigation }) {
  const { isDarkTheme, toggleTheme, currentTheme } = useThemeContext();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.colors.background }]}>
      <Text style={[styles.header, { color: currentTheme.colors.text }]}>
        Select a Student
      </Text>
      <View style={styles.toggleContainer}>
        <Text style={{ color: currentTheme.colors.text }}>Dark Mode</Text>
        <Switch
          value={isDarkTheme}
          onValueChange={toggleTheme}
          thumbColor={currentTheme.colors.primary}
        />
      </View>
      <FlatList
        data={students}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.studentItem, { backgroundColor: currentTheme.colors.card }]}
            onPress={() => navigation.navigate('Dashboard', { student: item })}
          >
            <Text style={[styles.studentName, { color: currentTheme.colors.text }]}>{item.name}</Text>
            <Text style={[styles.studentId, { color: currentTheme.colors.textSecondary }]}>
              ID: {item.studentId}
            </Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  header: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  toggleContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  studentItem: { padding: 16, borderRadius: 8, marginBottom: 12 },
  studentName: { fontSize: 16, fontWeight: 'bold' },
  studentId: { fontSize: 14 },
});
