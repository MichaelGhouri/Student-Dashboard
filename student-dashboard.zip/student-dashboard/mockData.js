const mockData = [
  {
    id: 1,
    name: 'Mobile Application & Development',
    code: 'CS-409',
    instructor: 'Mr. Shehzad Ahmed',
    timings: 'Wednesday 08:30 AM to 11:30 AM',
  },
  {
    id: 2,
    name: 'Data Science',
    code: 'SEN-251',
    instructor: 'Ms. Moona Kanwal',
    timings: 'Thursday 08:30 AM to 11:30 AM',
  },
  {
    id: 3,
    name: 'Software Quality Engineering',
    code: 'SEN-453',
    instructor: 'Dr. Abdul Rehman Baloch',
    timings: 'Thursday 11:45 AM to 02:45 PM',
  },
  
  {
    id: 4,
    name: 'Formal Methods in Software Engineering',
    code: 'SEN-450',
    instructor: 'Mr. Muhammad Tahir',
    timings: 'Friday 08:30 AM to 11:30 AM',
  },
  {
    id: 5,
    name: 'Sociology',
    code: 'HUM-113',
    instructor: 'Ms. Sabahat Raza',
    timings: 'Saturday 11:45 AM to 02:45 PM ',
  },
  {
    id: 6,
    name: 'Final Year Project - I',
    code: 'SEN-451',
    instructor: 'Mr. Fahad Najeeb',
    timings: 'Flexible',
  },
];

export default mockData;
