import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import mockData from './mockData';
import { useThemeContext } from './ThemeProvider';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function DashboardScreen({ route, navigation }) {
  const { currentTheme } = useThemeContext();
  const { student } = route.params;
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredCourses, setFilteredCourses] = useState(mockData);

  const handleSearch = (query) => {
    setSearchQuery(query);
    const filtered = mockData.filter(
      (course) =>
        course.name.toLowerCase().includes(query.toLowerCase()) ||
        course.code.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredCourses(filtered);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.colors.background }]}>
      <Text style={[styles.header, { color: currentTheme.colors.text }]}>
        {student.name}'s Dashboard
      </Text>
      <TextInput
        style={[styles.searchBar, { backgroundColor: currentTheme.colors.card, color: currentTheme.colors.text }]}
        placeholder="Search courses..."
        placeholderTextColor={currentTheme.colors.textSecondary}
        value={searchQuery}
        onChangeText={handleSearch}
      />
      <FlatList
        data={filteredCourses}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.courseItem, { backgroundColor: currentTheme.colors.card }]}
            onPress={() => navigation.navigate('CourseDetails', { course: item })}
          >
            <Text style={[styles.courseName, { color: currentTheme.colors.text }]}>{item.name}</Text>
            <Text style={[styles.courseCode, { color: currentTheme.colors.textSecondary }]}>{item.code}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  header: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  searchBar: { padding: 12, borderRadius: 8, marginBottom: 16 },
  courseItem: { padding: 16, borderRadius: 8, marginBottom: 12 },
  courseName: { fontSize: 16, fontWeight: 'bold' },
  courseCode: { fontSize: 14 },
});
