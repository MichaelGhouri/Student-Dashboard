import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { ThemeProvider, useThemeContext } from './ThemeProvider';
import StudentSelectionScreen from './StudentSelectionScreen';
import DashboardScreen from './DashboardScreen';
import CourseDetailsScreen from './CourseDetailsScreen';

const Stack = createStackNavigator();

function AppNavigator() {
  const { currentTheme } = useThemeContext();

  return (
    <NavigationContainer theme={currentTheme}>
      <Stack.Navigator>
        <Stack.Screen
          name="StudentSelection"
          component={StudentSelectionScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Dashboard"
          component={DashboardScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="CourseDetails"
          component={CourseDetailsScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppNavigator />
    </ThemeProvider>
  );
}
