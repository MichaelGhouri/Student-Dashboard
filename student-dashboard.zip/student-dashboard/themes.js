export const lightTheme = {
  background: '#FDF6EC',
  text: '#2C3E50',
  textSecondary: '#95A5A6',
  primary: '#3498DB',
  card: '#FFFFFF',
};

export const darkTheme = {
  background: '#121212',
  text: '#ECF0F1',
  textSecondary: '#95A5A6',
  primary: '#1ABC9C',
  card: '#1F1F1F',
};
